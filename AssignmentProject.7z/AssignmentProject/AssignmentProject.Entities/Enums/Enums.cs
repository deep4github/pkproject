﻿namespace AssignmentProject.Entities.Enums
{
    public enum ApiResponseType
    {
        Text,
        Json,
        Xml
    }
}
