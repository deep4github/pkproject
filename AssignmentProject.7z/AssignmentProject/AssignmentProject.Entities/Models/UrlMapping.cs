﻿namespace AssignmentProject.Entities.Models
{
    public class UrlMapping
    {
        public string CompanyName { get; set; }
        public string ApiUrl { get; set; }
    }
}
