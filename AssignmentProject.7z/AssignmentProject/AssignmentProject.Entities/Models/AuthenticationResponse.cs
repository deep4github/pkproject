﻿namespace AssignmentProject.Entities.Models
{
    public class AuthenticationResponse
    {
        public bool Authenticated { get; set; }
    }
}
