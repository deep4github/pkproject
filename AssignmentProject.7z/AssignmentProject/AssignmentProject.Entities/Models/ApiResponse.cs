﻿namespace AssignmentProject.Entities.Models
{
    public class ApiResponse
    {
        public string CompanyName { get; set; }
        public bool Success { get; set; }
        public decimal ShippingCharges { get; set; }
    }
}
