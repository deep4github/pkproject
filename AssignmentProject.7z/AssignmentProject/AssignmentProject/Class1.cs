﻿using System;

namespace AssignmentProject
{
    public class Class1
    {
    }
}
