﻿namespace WebApiProject
{
    public static class Constants
    {
        public static readonly string EcomExpress = "EcomExpress";
        public static readonly string FedexCourier = "FedexCourier";
        public static readonly string SafeExpress = "SafeExpress";
    }
}
