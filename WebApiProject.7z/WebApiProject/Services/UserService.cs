﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiProject.Helper;
using WebApiProject.Models;

namespace WebApiProject
{
    public interface IUserService
    {
        Task<User> Authenticate(string username, string password, int applicationId);
    }

    public class UserService : IUserService
    {
        List<User> users = DataManager.GetUsers();

        public async Task<User> Authenticate(string username, string password, int applicationId)
        {
            var user = await Task.Run(() =>
                users.SingleOrDefault(x => x.Username == username
                                            && x.Password == password
                                            && x.ApplicationId == applicationId));

            if (user == null)
                return null;

            return user.WithoutPassword();
        }
    }
}
